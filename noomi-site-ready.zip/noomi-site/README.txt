NOOMI SITE

1. Загрузи index.html в корень репозитория GitHub Pages.
2. APK размером 42 MB загрузи отдельно в GitHub Releases (не обычной кнопкой Upload files в репозитории).
3. Скопируй прямую ссылку на asset APK из релиза.
4. В index.html замени PASTE_DIRECT_APK_LINK_HERE на эту ссылку в строке DOWNLOAD_URL.
5. Сохрани (Commit changes) и дождись обновления GitHub Pages.

Важно: сам сайт ещё не опубликован. Для публикации нужен твой аккаунт GitHub и загрузка файлов в него.
